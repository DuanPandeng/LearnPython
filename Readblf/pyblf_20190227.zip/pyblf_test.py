from pyblf import *

# test
file = r"D:\ACC_01-01-01_HWA-A119_D_2018-03-30_T_16-06-13.blf"
Test(file)
